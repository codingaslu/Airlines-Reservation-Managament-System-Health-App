How to Run
Download/Install the following
Python (I used v3.9.1)
PIP (for python modules installation)

# Create a virtual environment (optional but recommended)
python -m venv venv

# Activate the virtual environment
# On Windows
venv\Scripts\activate


Setup/Installation


Run the following commands:
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver
Keep the terminals open and running.
Open a web browser and browse http://localhost:8000/ or http://127.0.0.1:8000/