# streamlit_interface.py

import streamlit as st
from PIL import Image

def display_header(title):
    st.header(title)

def display_text_input(label, key):
    return st.text_input(label, key=key)

def display_file_uploader(label, file_types):
    return st.file_uploader(label, type=file_types)

def display_image(image):
    st.image(image, caption="Uploaded Image.", use_column_width=True)

def display_button(label):
    return st.button(label)

def display_subheader(text):
    st.subheader(text)

def display_text(text):
    st.write(text)
